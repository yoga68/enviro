export interface Dictionary {
    [key: string]: any;
}
