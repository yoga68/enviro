<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('berita_model');
		$this->load->model('konfigurasi_model');
		$this->load->model('layanan_model');
		$this->load->model('galeri_model');
		$this->load->model('katlayanan_model');
	}

	public function index()
	{
		$konfigurasi = $this->konfigurasi_model->listing();
		$galeri = $this->galeri_model->slider();
		$layanan = $this->layanan_model->home();
		$katlayanan = $this->katlayanan_model->listing();
		$berita = $this->berita_model->home();

		$data = array('title' => $konfigurasi->namaweb,
					  'keywords' => $konfigurasi->namaweb.'-'.$konfigurasi->tagline.'-'.$konfigurasi->keywords,
					  'deskripsi' => $konfigurasi->deskripsi,
					  'galeri' => $galeri,
					  'berita' => $berita,
					  'katlayanan' => $katlayanan,
					  'layanan' => $layanan,
					  'isi'   => 'home/list'
	                 );		
		$this->load->view('layout/wrapper', $data, FALSE);
	}

}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */