<!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg align-items-center">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-sm-12">
                    <div class="breadcrumb_tittle">
                        <center><h2>404 Not Found</h2></center>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

  <!-- ================ contact section start ================= -->
  <section class="contact-section section_padding">
    <div class="container">
        <div class="col-md-12">
            <div class="alert-warning">
              <h4> 404 Not Found </h4>
              <p> Silahkan kembali ke halaman <a href="<?= base_url();?>"> Beranda</a></p>
            </div>
        </div>
    </div>
  </section>