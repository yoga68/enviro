<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berita extends CI_Controller {

	//main page
	public function index()
	{
		$data  = array('title' => 'News Enviro Buana Cipta',
					   'isi'   => 'berita/list'
					  );
		$this->load->view('layout/wrapper', $data, FALSE);
	}

	//detail page
	public function read()
	{
		$data  = array('title' => 'News Detail',
					   'isi'   => 'berita/read'
					  );
		$this->load->view('layout/wrapper', $data, FALSE);
	}

}

/* End of file Berita.php */
/* Location: ./application/controllers/Berita.php */