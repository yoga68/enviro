<?php 
//load view divariabel isi yg diset di controller
if($isi){
	$this->load->view($isi);
}

?>