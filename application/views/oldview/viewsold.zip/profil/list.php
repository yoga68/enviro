<!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg align-items-center">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-sm-6">
                    <div class="breadcrumb_tittle">
                        <p>home . about us</p>
                        <h2>about us</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

<!-- about part start-->
    <section class="creative padding_top">
      <div class="container-fluid">
        <div class="row align-items-center justify-content-start">
          <div class="col-md-6 col-xl-6">
            <div class="creative_img">
              <img src="<?= base_url();?>assets/template/img/creative_img.png" alt="" />
            </div>
          </div>
          <div class="col-md-6 col-xl-4">
            <div class="creative_part_text">
              <h2>We work hard and think creatively</h2>
              <p>
                There winged grass midst moving earth seed herb fifth you
                multiply you divide cattle stars first cattle.
              </p>
              <span
                >“There winged grass midst moving earth seed herb fifth you
                multiply you divide cattle stars first cattle.</span
              >
              <a
                href="https://www.youtube.com/watch?v=tDiJnd7SM2Y"
                class="popup-youtube"
                ><i class="ti-control-play"></i> See how we work</a
              >
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- about part end-->