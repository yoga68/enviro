<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="<?= $title; ?>">
    <meta name="keywords" content="<?= $title; ?>">
    <meta name="author" content="Yoga-EBC">
    <title><?= $title; ?></title>
    <link rel="icon" href="<?= base_url(); ?>assets/template/img/fixlogo.png" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/bootstrap.min.css" />
    <!-- animate CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/animate.css" />
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/owl.carousel.min.css" />
    <!-- themify CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/themify-icons.css" />
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/flaticon.css" />
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/magnific-popup.css" />
    <!-- swiper CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/slick.css" />
    <!-- style CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/template/css/style.css" />
  </head>

  <body>