<?php
//penggabungan
require_once('head.php');
require_once('nav.php');
require_once('content.php');
require_once('footer.php');
?>